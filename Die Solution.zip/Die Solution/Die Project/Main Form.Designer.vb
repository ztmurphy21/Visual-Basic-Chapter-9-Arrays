﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picDie1 = New System.Windows.Forms.PictureBox()
        Me.picDie2 = New System.Windows.Forms.PictureBox()
        Me.picDie4 = New System.Windows.Forms.PictureBox()
        Me.picDie3 = New System.Windows.Forms.PictureBox()
        Me.picDie6 = New System.Windows.Forms.PictureBox()
        Me.picDie5 = New System.Windows.Forms.PictureBox()
        Me.picRandDie = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.btnRoll = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnStartOver = New System.Windows.Forms.Button()
        Me.picPlaceHolder = New System.Windows.Forms.PictureBox()
        Me.lblPlaceHolder = New System.Windows.Forms.Label()
        CType(Me.picDie1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRandDie, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.picPlaceHolder, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picDie1
        '
        Me.picDie1.Image = Global.Die_Project.My.Resources.Resources.One
        Me.picDie1.Location = New System.Drawing.Point(12, 35)
        Me.picDie1.Name = "picDie1"
        Me.picDie1.Size = New System.Drawing.Size(49, 50)
        Me.picDie1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picDie1.TabIndex = 0
        Me.picDie1.TabStop = False
        '
        'picDie2
        '
        Me.picDie2.Image = Global.Die_Project.My.Resources.Resources.Two
        Me.picDie2.Location = New System.Drawing.Point(68, 35)
        Me.picDie2.Name = "picDie2"
        Me.picDie2.Size = New System.Drawing.Size(49, 50)
        Me.picDie2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picDie2.TabIndex = 1
        Me.picDie2.TabStop = False
        '
        'picDie4
        '
        Me.picDie4.Image = Global.Die_Project.My.Resources.Resources.Four
        Me.picDie4.Location = New System.Drawing.Point(180, 35)
        Me.picDie4.Name = "picDie4"
        Me.picDie4.Size = New System.Drawing.Size(49, 50)
        Me.picDie4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picDie4.TabIndex = 3
        Me.picDie4.TabStop = False
        '
        'picDie3
        '
        Me.picDie3.Image = Global.Die_Project.My.Resources.Resources.Three
        Me.picDie3.Location = New System.Drawing.Point(124, 35)
        Me.picDie3.Name = "picDie3"
        Me.picDie3.Size = New System.Drawing.Size(49, 50)
        Me.picDie3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picDie3.TabIndex = 2
        Me.picDie3.TabStop = False
        '
        'picDie6
        '
        Me.picDie6.Image = Global.Die_Project.My.Resources.Resources.Six
        Me.picDie6.Location = New System.Drawing.Point(292, 35)
        Me.picDie6.Name = "picDie6"
        Me.picDie6.Size = New System.Drawing.Size(49, 50)
        Me.picDie6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picDie6.TabIndex = 5
        Me.picDie6.TabStop = False
        '
        'picDie5
        '
        Me.picDie5.Image = Global.Die_Project.My.Resources.Resources.Five
        Me.picDie5.Location = New System.Drawing.Point(236, 35)
        Me.picDie5.Name = "picDie5"
        Me.picDie5.Size = New System.Drawing.Size(49, 50)
        Me.picDie5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picDie5.TabIndex = 4
        Me.picDie5.TabStop = False
        '
        'picRandDie
        '
        Me.picRandDie.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picRandDie.Location = New System.Drawing.Point(173, 34)
        Me.picRandDie.Name = "picRandDie"
        Me.picRandDie.Size = New System.Drawing.Size(49, 50)
        Me.picRandDie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picRandDie.TabIndex = 6
        Me.picRandDie.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lbl6)
        Me.GroupBox1.Controls.Add(Me.lbl4)
        Me.GroupBox1.Controls.Add(Me.lbl5)
        Me.GroupBox1.Controls.Add(Me.lbl2)
        Me.GroupBox1.Controls.Add(Me.lbl3)
        Me.GroupBox1.Controls.Add(Me.lbl1)
        Me.GroupBox1.Controls.Add(Me.picDie5)
        Me.GroupBox1.Controls.Add(Me.picDie6)
        Me.GroupBox1.Controls.Add(Me.picDie1)
        Me.GroupBox1.Controls.Add(Me.picDie2)
        Me.GroupBox1.Controls.Add(Me.picDie4)
        Me.GroupBox1.Controls.Add(Me.picDie3)
        Me.GroupBox1.Location = New System.Drawing.Point(33, 90)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(353, 146)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Counters"
        '
        'lbl6
        '
        Me.lbl6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl6.Location = New System.Drawing.Point(297, 104)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(39, 26)
        Me.lbl6.TabIndex = 11
        Me.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl4
        '
        Me.lbl4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl4.Location = New System.Drawing.Point(186, 104)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(39, 26)
        Me.lbl4.TabIndex = 7
        Me.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl5
        '
        Me.lbl5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl5.Location = New System.Drawing.Point(242, 104)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(39, 26)
        Me.lbl5.TabIndex = 9
        Me.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl2
        '
        Me.lbl2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl2.Location = New System.Drawing.Point(73, 104)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(39, 26)
        Me.lbl2.TabIndex = 3
        Me.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl3
        '
        Me.lbl3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl3.Location = New System.Drawing.Point(129, 104)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(39, 26)
        Me.lbl3.TabIndex = 5
        Me.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl1
        '
        Me.lbl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl1.Location = New System.Drawing.Point(17, 104)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(39, 26)
        Me.lbl1.TabIndex = 1
        Me.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnRoll
        '
        Me.btnRoll.Location = New System.Drawing.Point(403, 34)
        Me.btnRoll.Name = "btnRoll"
        Me.btnRoll.Size = New System.Drawing.Size(103, 31)
        Me.btnRoll.TabIndex = 0
        Me.btnRoll.Text = "&Roll"
        Me.btnRoll.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(403, 108)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(103, 31)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnStartOver
        '
        Me.btnStartOver.Location = New System.Drawing.Point(403, 71)
        Me.btnStartOver.Name = "btnStartOver"
        Me.btnStartOver.Size = New System.Drawing.Size(103, 31)
        Me.btnStartOver.TabIndex = 1
        Me.btnStartOver.Text = "&Start Over"
        Me.btnStartOver.UseVisualStyleBackColor = True
        '
        'picPlaceHolder
        '
        Me.picPlaceHolder.Location = New System.Drawing.Point(403, 186)
        Me.picPlaceHolder.Name = "picPlaceHolder"
        Me.picPlaceHolder.Size = New System.Drawing.Size(49, 50)
        Me.picPlaceHolder.TabIndex = 8
        Me.picPlaceHolder.TabStop = False
        Me.picPlaceHolder.Visible = False
        '
        'lblPlaceHolder
        '
        Me.lblPlaceHolder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPlaceHolder.Location = New System.Drawing.Point(458, 186)
        Me.lblPlaceHolder.Name = "lblPlaceHolder"
        Me.lblPlaceHolder.Size = New System.Drawing.Size(39, 50)
        Me.lblPlaceHolder.TabIndex = 4
        Me.lblPlaceHolder.Visible = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(536, 277)
        Me.Controls.Add(Me.lblPlaceHolder)
        Me.Controls.Add(Me.picPlaceHolder)
        Me.Controls.Add(Me.btnStartOver)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnRoll)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.picRandDie)
        Me.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Die Tracker"
        CType(Me.picDie1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRandDie, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.picPlaceHolder, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picDie1 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie2 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie4 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie3 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie6 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie5 As System.Windows.Forms.PictureBox
    Friend WithEvents picRandDie As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lbl6 As System.Windows.Forms.Label
    Friend WithEvents lbl4 As System.Windows.Forms.Label
    Friend WithEvents lbl5 As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents btnRoll As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnStartOver As System.Windows.Forms.Button
    Friend WithEvents picPlaceHolder As System.Windows.Forms.PictureBox
    Friend WithEvents lblPlaceHolder As System.Windows.Forms.Label

End Class
